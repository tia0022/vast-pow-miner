# vast-pow-miner

**Rent a GPU → mine a keccak256 PoW token → track live P&L → auto-stop on loss.**

Profile-driven: one YAML file per token. Ships with HASH256 as the reference.
Drop in any other PoW-ERC20 contract address, run one command, the tool builds
a profile and starts mining.

```
git clone https://github.com/YOUR_USERNAME/vast-pow-miner
cd vast-pow-miner
bash setup_vast.sh                      # installs CUDA toolkit, Rust, Python deps, miner
nano .env                                # paste PRIVATE_KEY
VAST_COST_PER_HOUR_USD=0.343 STOP_LOSS_USD=-3 bash start_mining.sh
```

> **Use this referral when signing up to vast.ai — it supports the author:**
> **👉 https://cloud.vast.ai/?ref_id=537207**

---

## Idiot-proof 5-step flow

1. **Sign up vast.ai** → [cloud.vast.ai/?ref_id=537207](https://cloud.vast.ai/?ref_id=537207), top up $10
2. **Rent a GPU** (RTX 4090/5090/L40S). Pick an image with CUDA 13+
3. **SSH in** and run:
   ```bash
   git clone https://github.com/YOUR_USERNAME/vast-pow-miner && cd vast-pow-miner
   bash setup_vast.sh
   ```
4. **Paste your mining-wallet private key** into `.env` (use a throwaway wallet with $10 ETH)
5. **Launch**:
   ```bash
   cd /root/hash256-miner     # or /root/<profile>-miner
   VAST_COST_PER_HOUR_USD=0.343 STOP_LOSS_USD=-3 bash start_mining.sh
   ```

Full step-by-step for beginners: [`docs/QUICKSTART.md`](docs/QUICKSTART.md).

---

## Honest economics (read this before you press RENT)

| HASH256 on RTX 5090 @ $0.343/hr | Value |
|---|---|
| Measured GPU hashrate | 5.76 GH/s |
| Estimated network hashrate | ~18.8 TH/s |
| Expected mints per hour | ~0.018 |
| Revenue per hour (100 HASH × $0.066) | ~$0.12 |
| vast.ai cost per hour | −$0.343 |
| **Net per hour** | **−$0.22 (loss)** |

**Right now, HASH256 loses money.** This repo exists so you can watch the
numbers in real time and auto-stop before you bleed. If HASH price 3x's, this
turns profitable instantly. If not — switch to another profile or stop.

---

## Mine a different token (not HASH256)

```bash
# Generate a profile from any Ethereum-mainnet ERC-20 PoW contract:
python3 bin/onboard.py \
    --contract 0xABCD...your_contract... \
    --name mytoken

# Validate it:
python3 bin/onboard.py --profile profiles/mytoken.yaml --validate

# Mine it:
PROFILE=mytoken VAST_COST_PER_HOUR_USD=0.343 STOP_LOSS_USD=-3 bash start_mining.sh
```

`onboard.py` fetches the contract ABI from Etherscan, guesses which function is
`mine()`, writes a profile YAML. You may need to edit 1-2 fields if heuristics
don't match — see comments in `profiles/template.yaml`.

Supported chains: Ethereum, Polygon, Base, Arbitrum (anywhere Etherscan-family
explorers exist).

Supported hash algorithm: **keccak256** (0xBitcoin / HASH256 / any token that
computes `hash = keccak256(abi.encodePacked(challenge, msg.sender, nonce))`
and requires `hash < difficulty`).

More: [`docs/ADD_PROFILE.md`](docs/ADD_PROFILE.md).

---

## Architecture

```
vast-pow-miner/
├── profiles/
│   ├── hash256.yaml          # reference profile (tested)
│   ├── template.yaml         # blank template
│   └── README.md             # how to contribute
├── bin/
│   ├── onboard.py            # contract addr → profile YAML
│   ├── generic_monitor.py    # profile-driven real-time P&L
│   └── scan_mints.py         # count mint activity for a profile
├── setup_vast.sh             # one-shot provisioning
├── start_mining.sh           # launch miner + monitor in tmux
├── .env.example
├── docs/
│   ├── QUICKSTART.md         # step-by-step with screenshots
│   └── ADD_PROFILE.md        # adding a new token
└── LICENSE (MIT)
```

---

## Auto-stop triggers

`bin/generic_monitor.py` kills the miner tmux session when:

1. **Net P&L ≤ `STOP_LOSS_USD`** (default −$10)
2. **Token price drops ≥ `HASH_DROP_PCT_STOP`%** from session peak (default 50%)
3. **ETH balance too low for 1 tx** — warns, doesn't stop

Every 30s it writes `profit_status.json` with a full P&L snapshot.

---

## Security checklist

- ☐ Use a **fresh wallet** with only gas ETH ($10-15)
- ☐ Withdraw mined tokens regularly (host could read `.env`)
- ☐ Burn the wallet when you're done with the session
- ☐ Use your own Alchemy/Infura RPC, not the public fallback
- ☐ Set `STOP_LOSS_USD` conservatively (−$3 for a first test run)

---

## Disclaimer

**Not financial advice.** You are responsible for rental costs, gas costs, wallet
security, and any lost funds. Token liquidity for brand-new PoW coins is often
<$100k — a single whale sell crashes the price instantly. Always run the monitor
first; never YOLO.

## License

MIT — see [`LICENSE`](LICENSE).

## Support

- ⭐ Star this repo
- 🔗 Sign up via [vast.ai referral](https://cloud.vast.ai/?ref_id=537207)
- 🐛 Open issues / PRs with new profiles
