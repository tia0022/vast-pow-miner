# 傻瓜式快速上手 / Idiot-proof Quickstart

> 面向完全没有挖矿经验的新手 / For absolute beginners.

---

## 中文版

### 第 1 步 · 注册 vast.ai

1. 打开 **👉 https://cloud.vast.ai/?ref_id=537207** 注册
2. 邮箱验证 → 登录
3. 右上角 **Billing → Add Credit**，充值 $10-20（支持信用卡/加密货币）

### 第 2 步 · 准备 SSH 密钥

打开本地终端（Mac：`Terminal.app`；Windows：`PowerShell`；Linux：任意终端）：

```bash
# 如果你还没有 SSH 密钥，生成一个（一直回车即可）
ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519 -N ""

# 复制公钥内容
cat ~/.ssh/id_ed25519.pub
```

把复制的内容贴到 **vast.ai → 右上角头像 → Account → SSH Keys → Add Public Key**。

### 第 3 步 · 创建一次性挖矿钱包

**重要：不要用你的主钱包。**

1. 装 MetaMask → 点右上角头像 → **Add account → Add a new account** → 命名 "mining"
2. 给它**转 $10-15 的 ETH**（gas 费用）
3. 点新账户 → **Account details → Show private key**，输入密码，记下私钥

### 第 4 步 · 租一台 GPU

1. vast.ai → 左侧 **Search**
2. 筛选 **GPU Type = RTX 5090**（或 4090、L40S）
3. 按 **$/GPU hr** 从低到高排序
4. 选一台 CUDA 13+ 的（镜像推荐 `vastai/base-image_cuda-13.0.2-auto`）
5. 点 **RENT**，等 "Running" 状态

启动后页面会显示 SSH 命令，例如：

```
ssh -p 33824 root@120.238.149.205
```

### 第 5 步 · 一键部署

复制上面那条 SSH 命令，到本地终端运行。进去后：

```bash
cd /root
git clone https://github.com/YOUR_USERNAME/vast-pow-miner
cd vast-pow-miner
bash setup_vast.sh
```

等 10-15 分钟（装 CUDA 工具链、Rust、编译矿机），看到 `Setup complete.` 就成功了。

### 第 6 步 · 填入私钥

```bash
cd /root/hash256-miner     # setup 最后会告诉你具体目录
nano .env
```

把 `PRIVATE_KEY=` 后面改成你第 3 步记下的私钥（以 `0x` 开头）。`Ctrl-O` 保存，`Ctrl-X` 退出。

### 第 7 步 · 开挖

```bash
VAST_COST_PER_HOUR_USD=0.343 STOP_LOSS_USD=-3 bash start_mining.sh
```

`VAST_COST_PER_HOUR_USD` 填你 vast.ai 页面上显示的 `$/hr`（例如 $0.343）。
`STOP_LOSS_USD` 是亏多少自动停机（建议新手 -$3）。

### 第 8 步 · 查看状态

```bash
tmux attach -t hash256-miner     # 矿机面板（hashrate、TX 数量）
# 退出按 Ctrl-B 然后 D

tmux attach -t hash256-profit    # 盈亏监控（每 30s 一行）

cat profit_status.json | jq      # JSON 状态
```

### 第 9 步 · 决定是否继续

跑 30-60 分钟后看 `profit_status.json` 里的 `usd.net_pnl`：

- 正数 ✅：可以继续跑
- 一直负数 ❌：自动止损会 kill 矿机，你也可以手动 `tmux kill-session -t hash256-miner`

### 第 10 步 · 提现（如果真挖到了）

1. **本地**电脑上，用 MetaMask 导入挖矿钱包私钥
2. 从 MetaMask 把 HASH 或其他代币发到你的主钱包
3. 完成后从 MetaMask 移除这个账户
4. vast.ai 上点 **Destroy** 销毁实例

---

## English version

Same steps, compressed:

```bash
# 1. Sign up vast.ai via referral: https://cloud.vast.ai/?ref_id=537207
# 2. Add your SSH public key (~/.ssh/id_ed25519.pub) to Account → SSH Keys
# 3. Create a throwaway wallet (MetaMask → Add account). Send it $10-15 ETH.
# 4. Rent a GPU with CUDA 13+ image. Copy the SSH command.

# 5. SSH in and provision:
ssh -p <port> root@<host>
git clone https://github.com/YOUR_USERNAME/vast-pow-miner
cd vast-pow-miner
bash setup_vast.sh

# 6. Paste your private key into .env:
cd /root/hash256-miner
nano .env       # edit PRIVATE_KEY=0x...

# 7. Start mining:
VAST_COST_PER_HOUR_USD=0.343 STOP_LOSS_USD=-3 bash start_mining.sh

# 8. Watch:
tmux attach -t hash256-miner
tmux attach -t hash256-profit
cat profit_status.json | jq

# 9. After 30-60 min, check profit_status.json → usd.net_pnl
#    positive = keep going; auto-stop will kill miner on loss.

# 10. Withdraw earnings locally (MetaMask import → send → burn account).
#     Destroy vast.ai instance from the dashboard.
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `nvcc not found` | You picked a non-CUDA image. Destroy instance, pick `vastai/base-image_cuda-13.0.2-auto`. |
| `ABORT: wallet balance too low` | Your mining wallet needs ~$5+ ETH. Top it up. |
| `tmux: command not found` | `apt install -y tmux` (rare, `setup_vast.sh` installs it) |
| Miner shows 0 GH/s | GPU driver not loaded. Try `nvidia-smi` first. If fails, instance broken — destroy + rent new one. |
| SSH disconnects and miner dies | Use tmux (the scripts already do). Your local SSH dropping doesn't kill tmux sessions. |
| Monitor says `DexScreener returned no pairs` | Token has no DEX liquidity yet — monitor won't know your USD value but miner still runs. |

## Cost estimates for a day of testing

- Vast.ai RTX 5090 @ $0.343/hr × 24 h = **$8.23**
- Gas on Ethereum (≈ 0.5 tx × $0.50) = **$0.25**
- Token earned (depends on price + difficulty)

Expect to spend $5-10 exploring. Don't bet more than you can afford to lose.
