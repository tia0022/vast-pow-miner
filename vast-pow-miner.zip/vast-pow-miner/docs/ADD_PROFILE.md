# Adding a new token profile

This framework supports **any ERC-20 on an Etherscan-family chain where the PoW
uses keccak256** and the mine function takes a `uint256` nonce (possibly with
extra args). That's ~90% of 0xBitcoin-clone tokens.

---

## Fast path — auto-generate from contract address

```bash
# 1. Get a free Etherscan API key at https://etherscan.io/myapikey
export ETHERSCAN_API_KEY=YOUR_KEY

# 2. Generate profile
python3 bin/onboard.py \
    --contract 0xYourTokenContract \
    --name yourtoken \
    --chain-id 1                           # 1=eth, 137=polygon, 8453=base, 42161=arb

# 3. Review the generated YAML
cat profiles/yourtoken.yaml

# 4. Validate
python3 bin/onboard.py --profile profiles/yourtoken.yaml --validate
```

What `onboard.py` does:

1. Fetches the **verified ABI** from Etherscan-family explorer
2. Heuristically picks:
   - Non-view function whose name contains `mine`/`submit`/`claim` → `mine_fn`
   - View functions containing `challenge` / `difficulty` / `reward` → `views`
3. Computes the 4-byte selector from the guessed `mine()` signature
4. Writes `profiles/<name>.yaml` with best-effort defaults

Fields you may need to hand-edit:

- `hash_input_template.pack_order` — ordering used when your contract packs data
  before hashing. Most 0xBitcoin clones use `[challenge, address, nonce]`. If
  your target contract uses something different, check its `mine()` source on
  Etherscan.
- `contract.mine_fn.args` — placeholder list. If your `mine()` takes extra
  arguments, fill them in (e.g. a challenge hash).
- `miner.repo` — by default points at `ulsreall/hash256-cli`. This miner only
  works if the target contract uses **exactly the HASH256 packing + selector**.
  For a different selector, fork the miner and update the args + selector in
  its Rust source, then point `miner.repo` at your fork.

---

## Manual path

If Etherscan doesn't have the ABI (unverified contract):

```bash
cp profiles/template.yaml profiles/yourtoken.yaml
nano profiles/yourtoken.yaml     # fill every REPLACE_ME
python3 bin/onboard.py --profile profiles/yourtoken.yaml --validate
```

To compute the `mine_fn.selector` by hand:

```bash
python3 -c "from eth_utils import keccak; print('0x'+keccak(text='mine(uint256)').hex()[:8])"
# → 0x4d474898
```

---

## What about non-keccak256 algorithms?

You need to swap out the miner binary:

- **Blake2b** (Kadena-style) — fork a Blake2b CUDA miner
- **SHA3-512 / Scrypt / Equihash** — each needs its own kernel

Update `miner.repo`, `miner.build_command`, `miner.binary_path` in the profile.
The monitor / P&L code stays the same since it only reads on-chain state.

---

## Contribute a profile

1. Fork this repo
2. Add `profiles/yourtoken.yaml` (fully tested and validating)
3. Add a row to `profiles/README.md` listing your token
4. Open a PR with a link to a successful mine tx on Etherscan as proof

Profiles we'd love to receive:

- 0xBitcoin (0xB6eD7644C69416d67B522e20bC294A9a9B405B31)
- BitcoinEther
- Other Ethereum / Polygon / Base keccak256 PoW ERC-20s
