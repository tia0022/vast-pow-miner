#!/bin/bash
# setup_vast.sh — one-shot provisioning for a vast.ai GPU instance.
# Profile-aware: reads profiles/<PROFILE>.yaml to decide which miner repo to build.
#
# Usage:
#   bash setup_vast.sh                  # defaults to PROFILE=hash256
#   PROFILE=yourtoken bash setup_vast.sh

set -euo pipefail

PROFILE="${PROFILE:-hash256}"
REPO_ROOT="$(cd "$(dirname "$0")" && pwd)"
PROFILE_FILE="$REPO_ROOT/profiles/$PROFILE.yaml"

echo "======================================"
echo "  vast-pow-miner setup"
echo "  Profile: $PROFILE"
echo "  File:    $PROFILE_FILE"
echo "======================================"

test -f "$PROFILE_FILE" || { echo "ERROR: profile not found: $PROFILE_FILE"; exit 1; }

# Install yq-lite via python for profile reading (pyyaml already needed)
export DEBIAN_FRONTEND=noninteractive
echo ">>> [1/6] OS packages"
apt-get update -y >/dev/null
apt-get install -y --no-install-recommends \
    build-essential pkg-config libssl-dev \
    git curl ca-certificates \
    python3 python3-venv python3-pip \
    tmux jq zip >/dev/null

echo ">>> [2/6] Read profile settings"
WORK_DIR="/root/vast-pow-miner-work"
mkdir -p "$WORK_DIR"
python3 - "$PROFILE_FILE" > "$WORK_DIR/profile.env" <<'PY'
import sys, yaml
with open(sys.argv[1]) as f:
    p = yaml.safe_load(f)
print(f"MINER_REPO={p['miner']['repo']}")
print(f"MINER_BUILD_CMD={p['miner']['build_command']}")
print(f"MINER_BIN={p['miner']['binary_path']}")
print(f"TMUX_SESSION={p['miner'].get('tmux_session', p['name']+'-miner')}")
print(f"PROFILE_NAME={p['name']}")
PY
# shellcheck disable=SC1091
source "$WORK_DIR/profile.env"
echo "  Miner repo:     $MINER_REPO"
echo "  Build command:  $MINER_BUILD_CMD"
echo "  Binary path:    $MINER_BIN"
echo "  tmux session:   $TMUX_SESSION"

echo ">>> [3/6] CUDA toolkit check"
if ! command -v nvcc >/dev/null 2>&1; then
    CUDA_DIR=$(ls -d /usr/local/cuda* 2>/dev/null | head -1 || true)
    [ -n "$CUDA_DIR" ] || { echo "ERROR: CUDA toolkit not found. Pick a vastai CUDA image."; exit 1; }
    export PATH="$CUDA_DIR/bin:$PATH"
fi
nvcc --version | tail -1
nvidia-smi --query-gpu=name,memory.total --format=csv,noheader,nounits | head -5

echo ">>> [4/6] Rust toolchain"
if ! command -v cargo >/dev/null 2>&1; then
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs \
        | sh -s -- -y --default-toolchain stable --profile minimal >/dev/null
fi
# shellcheck disable=SC1091
source "$HOME/.cargo/env"
rustc --version

echo ">>> [5/6] Clone + build miner (${MINER_REPO})"
MINER_DIR="/root/${PROFILE_NAME}-miner"
if [ ! -d "$MINER_DIR" ]; then
    git clone "$MINER_REPO" "$MINER_DIR"
fi
cd "$MINER_DIR"
git pull --rebase || true

# Prefer repo's own build script if present
if [ -x ./build.sh ]; then
    ./build.sh
else
    eval "$MINER_BUILD_CMD"
fi
test -x "$MINER_DIR/$MINER_BIN" || {
    echo "ERROR: miner binary not found at $MINER_DIR/$MINER_BIN after build"
    exit 1
}

echo ">>> [6/6] Python venv + deps for monitor/onboard"
python3 -m venv "$WORK_DIR/venv"
"$WORK_DIR/venv/bin/pip" install --no-cache-dir --upgrade pip >/dev/null
"$WORK_DIR/venv/bin/pip" install --no-cache-dir \
    pyyaml==6.0.2 web3==6.20.3 eth-account==0.13.5 eth-utils==4.1.1 requests==2.32.3 >/dev/null

# Copy / symlink profile + scripts into miner dir so start_mining.sh is self-contained
ln -sf "$REPO_ROOT/profiles" "$MINER_DIR/profiles"
ln -sf "$REPO_ROOT/bin"      "$MINER_DIR/bin"
cp -f  "$REPO_ROOT/start_mining.sh" "$MINER_DIR/start_mining.sh"
chmod +x "$MINER_DIR/start_mining.sh"

# .env template
if [ ! -f "$MINER_DIR/.env" ]; then
    cp "$REPO_ROOT/.env.example" "$MINER_DIR/.env"
fi

cat <<EOF

======================================================================
  Setup complete.

  Next steps:
    1. Edit credentials:
         nano $MINER_DIR/.env
         (set PRIVATE_KEY; optional: set RPC_URL)

    2. (Optional) Validate profile:
         $WORK_DIR/venv/bin/python3 $REPO_ROOT/bin/onboard.py \\
             --profile $REPO_ROOT/profiles/$PROFILE.yaml --validate

    3. Launch mining + monitor:
         cd $MINER_DIR
         PROFILE=$PROFILE VAST_COST_PER_HOUR_USD=0.343 STOP_LOSS_USD=-3 \\
             bash start_mining.sh

  Watch:
    tmux attach -t $TMUX_SESSION        # miner
    tmux attach -t ${PROFILE}-profit    # P&L monitor
    cat $MINER_DIR/profit_status.json | jq
======================================================================
EOF
