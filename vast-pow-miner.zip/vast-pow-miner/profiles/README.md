# Profiles

One YAML file per token. The rest of the tooling is driven entirely by these files.

## Existing profiles

| File | Token | Chain |
|---|---|---|
| `hash256.yaml` | HASH256 (reference, fully tested) | Ethereum mainnet |

## Add a new token

**Fast path (auto-generate from contract address):**

```bash
python3 bin/onboard.py \
    --contract 0xYourTokenContract \
    --name yourtoken \
    --rpc https://ethereum-rpc.publicnode.com
```

This fetches the ABI from Etherscan, guesses `mine()` signature and other
view functions, and writes `profiles/yourtoken.yaml` with best-effort defaults.

**Manual path:** copy `template.yaml` and edit it. See comments in the file.

## Validate a profile

```bash
python3 bin/onboard.py --profile profiles/yourtoken.yaml --validate
```

Validator checks:
- Required fields present
- Contract responds to declared view functions
- `mine_fn.selector` matches `keccak256(signature)[:4]`
- Chain `rpc_default` is reachable
- DexScreener has data for the token (warning only)

## Contribute

PRs welcome — add your profile and open an issue linking proof it mines.
