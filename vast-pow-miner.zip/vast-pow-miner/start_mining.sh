#!/bin/bash
# start_mining.sh — profile-driven miner launcher.
# Pre-flights wallet, spawns miner tmux + monitor tmux.
#
# Env (all optional except PRIVATE_KEY in .env):
#   PROFILE                  default hash256
#   VAST_COST_PER_HOUR_USD   default 0
#   STOP_LOSS_USD            default -10
#   RPC_URL                  overrides profile default
#
# Usage:
#   PROFILE=hash256 VAST_COST_PER_HOUR_USD=0.343 STOP_LOSS_USD=-3 bash start_mining.sh

set -euo pipefail

PROFILE="${PROFILE:-hash256}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROFILE_FILE="$SCRIPT_DIR/profiles/$PROFILE.yaml"
test -f "$PROFILE_FILE" || { echo "ERROR: profile $PROFILE_FILE not found"; exit 1; }

# Load .env
if [ -f "$SCRIPT_DIR/.env" ]; then
    set -a; source "$SCRIPT_DIR/.env"; set +a
fi
[ -n "${PRIVATE_KEY:-}" ] || { echo "ERROR: PRIVATE_KEY not set (edit .env)"; exit 1; }

# Python helper
VENV_PY="/root/vast-pow-miner-work/venv/bin/python3"
[ -x "$VENV_PY" ] || VENV_PY="$(command -v python3)"

# Extract profile values we need
eval $(
"$VENV_PY" - "$PROFILE_FILE" <<'PY'
import sys, yaml
with open(sys.argv[1]) as f:
    p = yaml.safe_load(f)
print(f"MINER_BIN={p['miner']['binary_path']}")
print(f"TMUX_MINER={p['miner'].get('tmux_session', p['name']+'-miner')}")
print(f"TMUX_PROFIT={p['name']}-profit")
print(f"PROFILE_NAME={p['name']}")
print(f"RPC_DEFAULT={p['chain']['rpc_default']}")
print(f"CONTRACT={p['contract']['address']}")
PY
)

# Respect env override of RPC_URL, else use profile default
export RPC_URL="${RPC_URL:-$RPC_DEFAULT}"
export PRIVATE_KEY

echo "========================================"
echo "  vast-pow-miner"
echo "  Profile:   $PROFILE_NAME"
echo "  Contract:  $CONTRACT"
echo "  RPC:       $RPC_URL"
echo "  Miner bin: $MINER_BIN"
echo "========================================"

# Pre-flight ----------------------------------------------------------------
echo ""
echo "=== Pre-flight checks ==="
"$VENV_PY" - <<PY
import os
from web3 import Web3
from eth_account import Account

w3   = Web3(Web3.HTTPProvider(os.environ["RPC_URL"], request_kwargs={"timeout": 15}))
acct = Account.from_key(os.environ["PRIVATE_KEY"])
bal  = w3.eth.get_balance(acct.address)
gp   = max(w3.eth.gas_price, 10**9)
need = 250_000 * gp
print(f"ADDR            = {acct.address}")
print(f"ETH balance     = {bal/1e18:.6f}  ({bal} wei)")
print(f"Gas price       = {gp/1e9:.2f} gwei")
print(f"Need per tx     = {need/1e18:.6f} ETH")
if bal < need:
    print("FAIL: wallet balance too low to cover 1 mining tx")
    raise SystemExit(1)
print("OK: wallet funded")
PY

# Verify miner binary exists
if [ ! -x "./$MINER_BIN" ]; then
    echo ""
    echo "ERROR: miner binary './$MINER_BIN' not found. Did you run setup_vast.sh?"
    exit 1
fi

# Kill any existing sessions
tmux kill-session -t "$TMUX_MINER"  2>/dev/null || true
tmux kill-session -t "$TMUX_PROFIT" 2>/dev/null || true

# Launch miner --------------------------------------------------------------
echo ""
echo "=== Launching miner (tmux: $TMUX_MINER) ==="
tmux new-session -d -s "$TMUX_MINER" \
    "set -a; source .env 2>/dev/null || true; set +a; \
     export RPC_URL='$RPC_URL'; \
     GPU=1 ./$MINER_BIN 2>&1 | tee miner.log"

# Launch monitor ------------------------------------------------------------
echo "=== Launching P&L monitor (tmux: $TMUX_PROFIT) ==="
tmux new-session -d -s "$TMUX_PROFIT" \
    "set -a; source .env 2>/dev/null || true; set +a; \
     PROFILE='$PROFILE_NAME' \
     RPC_URL='$RPC_URL' \
     TMUX_SESSION='$TMUX_MINER' \
     VAST_COST_PER_HOUR_USD='${VAST_COST_PER_HOUR_USD:-0}' \
     STOP_LOSS_USD='${STOP_LOSS_USD:--10}' \
     STATUS_FILE='./profit_status.json' \
     LOG_FILE='./profit.log' \
     '$VENV_PY' bin/generic_monitor.py"

sleep 2
tmux ls
echo ""
echo "Attach:"
echo "  tmux attach -t $TMUX_MINER      # miner"
echo "  tmux attach -t $TMUX_PROFIT     # P&L"
echo "JSON status: cat profit_status.json | jq"
echo "Detach: Ctrl-B then D"
echo "Stop:   tmux kill-session -t $TMUX_MINER; tmux kill-session -t $TMUX_PROFIT"
